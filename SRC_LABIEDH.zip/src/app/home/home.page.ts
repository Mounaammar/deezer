import { Component } from '@angular/core';
import { NavigationExtras, Router } from '@angular/router';
import { Artist } from '../service/data/Artist';
import { DataSearchArtist } from '../service/DataSearchArtist';
import { DeezerService } from '../service/deezer.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {

  listArtist: Artist[];
  constructor(public DeezService :DeezerService,public router : Router) {}

  async onSearchArtist(event: any){
    let val = event.target.value;
    let oup:DataSearchArtist = await this.DeezService.getAuthors(val);
    this.listArtist = oup.data;
  }

  async onSearchAlbum(nom: string){
    this.router.navigate(['list-album/:'+nom]);
  }

}

 