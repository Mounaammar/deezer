import { Component, OnInit, Renderer2 } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Track } from '../service/data/Track';
import { DataSearchTrack } from '../service/DataSearchTrack';
import { DeezerService } from '../service/deezer.service';

@Component({
  selector: 'app-list-track',
  templateUrl: './list-track.page.html',
  styleUrls: ['./list-track.page.scss'],
})
export class ListTrackPage implements OnInit {
  isShow = false;
  TAG: string = "ListTrackPage";
  title:  string;
  id: string;
  listTracks: Track[];
  name : string;
  count : number;
  image : string;
  constructor(public DeezService :DeezerService,public route : ActivatedRoute, public render : Renderer2) { }

  async ngOnInit() {
     this.id=this.route.snapshot.paramMap.get("id");
     console.log("My id in list Track page is   "+this.id);
     let oup : DataSearchTrack =await this.DeezService.getTracks(this.id);
     this.listTracks=oup.tracks.data;
     console.log(oup.title);
     /*this.name=oup.title;
     this.image=oup.cover;
    this.count=this.listTracks.length;*/
   
   }
 
 
   

}
