import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { Album } from '../service/data/Album';
import { DataSearchAlbum } from '../service/DataSearchAlbum';
import { DeezerService } from '../service/deezer.service';

@Component({
  selector: 'app-list-album',
  templateUrl: './list-album.page.html',
  styleUrls: ['./list-album.page.scss'],
})
export class ListAlbumPage implements OnInit {
  TAG: string = "ListAlbumPage";
  title:  string;
  listAlbum: Album[];
  constructor(public DeezService :DeezerService,public route : ActivatedRoute,public router : Router) { }

  async ngOnInit() {
    this.title = this.route.snapshot.paramMap.get("name");
    let oup:DataSearchAlbum = await this.DeezService.getAlbum(this.title);
    this.listAlbum = oup.data;
  }

  async onSearchTrack(id:string){
    this.router.navigate(['list-tracks/:'+id]);
    console.log(id+ 'is written');
  }

}
