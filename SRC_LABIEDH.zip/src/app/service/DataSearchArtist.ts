import { Artist } from "./data/Artist";

export class DataSearchArtist{
    data: Artist[];
    total: number;
    next: string;
}