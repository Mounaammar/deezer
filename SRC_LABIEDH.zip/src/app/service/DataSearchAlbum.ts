import { Album } from "./data/Album";

export class DataSearchAlbum{
    data: Album[];
    total: number;
    next: string;
}