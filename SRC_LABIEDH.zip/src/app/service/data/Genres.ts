import { Genre } from "./genre";

export class Genres{
    data: Genre[];
}