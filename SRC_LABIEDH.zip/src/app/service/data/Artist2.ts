export class Artist2{
    id: number;
    name: string;
    tracklist: string;
    type: string;
}