import { Track } from "./Track";

export class Tracks{
    data : Track[];
}